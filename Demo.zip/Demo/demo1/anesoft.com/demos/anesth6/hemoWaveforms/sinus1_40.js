sinus1[40] = {
    "HemoNpoints": 150, 
    "RhythmDescription": "Sinus Bradycardia", 
    "RhythmRate": 40, 
    "hemoPoints": [
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -2, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": 0, 
            "EcgIIHt": -1, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -2, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": 0, 
            "EcgIIHt": -1, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -2, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -1, 
            "EcgIIHt": -2, 
            "EcgTag": 0, 
            "EcgV5Ht": -1, 
            "PapHt": -2, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -1, 
            "EcgIIHt": -2, 
            "EcgTag": 0, 
            "EcgV5Ht": -1, 
            "PapHt": -2, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -1, 
            "EcgIIHt": -3, 
            "EcgTag": 0, 
            "EcgV5Ht": -2, 
            "PapHt": -2, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -1, 
            "EcgIIHt": -3, 
            "EcgTag": 0, 
            "EcgV5Ht": -2, 
            "PapHt": -2, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -2, 
            "EcgIIHt": -2, 
            "EcgTag": 0, 
            "EcgV5Ht": -2, 
            "PapHt": -2, 
            "SpHt": -1
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -2, 
            "EcgIIHt": -2, 
            "EcgTag": 0, 
            "EcgV5Ht": -1, 
            "PapHt": -2, 
            "SpHt": -1
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -3, 
            "EcgIIHt": -1, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -1, 
            "SpHt": -1
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -3, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -1, 
            "SpHt": -1
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -4, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -1, 
            "SpHt": -1
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -4, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -1, 
            "SpHt": -1
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -5, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -1, 
            "SpHt": -1
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -5, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -1, 
            "SpHt": -1
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -5, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -1, 
            "SpHt": -1
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -4, 
            "EcgIIHt": 1, 
            "EcgTag": 0, 
            "EcgV5Ht": 1, 
            "PapHt": -1, 
            "SpHt": 0
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -4, 
            "EcgIIHt": 3, 
            "EcgTag": 0, 
            "EcgV5Ht": 3, 
            "PapHt": -1, 
            "SpHt": 0
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -3, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -1, 
            "SpHt": 0
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -3, 
            "EcgIIHt": -10, 
            "EcgTag": 0, 
            "EcgV5Ht": -6, 
            "PapHt": -1, 
            "SpHt": 0
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -2, 
            "EcgIIHt": -20, 
            "EcgTag": 0, 
            "EcgV5Ht": -12, 
            "PapHt": -1, 
            "SpHt": 0
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -2, 
            "EcgIIHt": -10, 
            "EcgTag": 3, 
            "EcgV5Ht": -6, 
            "PapHt": 0, 
            "SpHt": 0
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -3, 
            "EcgIIHt": 3, 
            "EcgTag": 0, 
            "EcgV5Ht": 6, 
            "PapHt": 0, 
            "SpHt": 0
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -3, 
            "EcgIIHt": 2, 
            "EcgTag": 0, 
            "EcgV5Ht": 4, 
            "PapHt": 0, 
            "SpHt": 0
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -3, 
            "EcgIIHt": 1, 
            "EcgTag": 0, 
            "EcgV5Ht": 2, 
            "PapHt": 0, 
            "SpHt": 0
        }, 
        {
            "AbpHt": 0, 
            "CvpHt": -2, 
            "EcgIIHt": 1, 
            "EcgTag": 0, 
            "EcgV5Ht": 1, 
            "PapHt": -1, 
            "SpHt": 0
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -2, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -1, 
            "SpHt": 0
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -1, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": 0
        }, 
        {
            "AbpHt": -1, 
            "CvpHt": -1, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -9, 
            "SpHt": -1
        }, 
        {
            "AbpHt": -4, 
            "CvpHt": 0, 
            "EcgIIHt": -1, 
            "EcgTag": 0, 
            "EcgV5Ht": -1, 
            "PapHt": -18, 
            "SpHt": -1
        }, 
        {
            "AbpHt": -9, 
            "CvpHt": 0, 
            "EcgIIHt": -1, 
            "EcgTag": 0, 
            "EcgV5Ht": -1, 
            "PapHt": -19, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -18, 
            "CvpHt": 1, 
            "EcgIIHt": -2, 
            "EcgTag": 0, 
            "EcgV5Ht": -2, 
            "PapHt": -20, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -19, 
            "CvpHt": 1, 
            "EcgIIHt": -3, 
            "EcgTag": 0, 
            "EcgV5Ht": -3, 
            "PapHt": -20, 
            "SpHt": -7
        }, 
        {
            "AbpHt": -20, 
            "CvpHt": 2, 
            "EcgIIHt": -4, 
            "EcgTag": 0, 
            "EcgV5Ht": -4, 
            "PapHt": -19, 
            "SpHt": -10
        }, 
        {
            "AbpHt": -20, 
            "CvpHt": 2, 
            "EcgIIHt": -6, 
            "EcgTag": 0, 
            "EcgV5Ht": -5, 
            "PapHt": -17, 
            "SpHt": -13
        }, 
        {
            "AbpHt": -19, 
            "CvpHt": 3, 
            "EcgIIHt": -8, 
            "EcgTag": 0, 
            "EcgV5Ht": -5, 
            "PapHt": -16, 
            "SpHt": -15
        }, 
        {
            "AbpHt": -17, 
            "CvpHt": 3, 
            "EcgIIHt": -9, 
            "EcgTag": 0, 
            "EcgV5Ht": -6, 
            "PapHt": -15, 
            "SpHt": -16
        }, 
        {
            "AbpHt": -16, 
            "CvpHt": 3, 
            "EcgIIHt": -9, 
            "EcgTag": 0, 
            "EcgV5Ht": -6, 
            "PapHt": -14, 
            "SpHt": -17
        }, 
        {
            "AbpHt": -15, 
            "CvpHt": 2, 
            "EcgIIHt": -9, 
            "EcgTag": 0, 
            "EcgV5Ht": -6, 
            "PapHt": -13, 
            "SpHt": -18
        }, 
        {
            "AbpHt": -14, 
            "CvpHt": 2, 
            "EcgIIHt": -8, 
            "EcgTag": 0, 
            "EcgV5Ht": -5, 
            "PapHt": -12, 
            "SpHt": -19
        }, 
        {
            "AbpHt": -13, 
            "CvpHt": 1, 
            "EcgIIHt": -5, 
            "EcgTag": 0, 
            "EcgV5Ht": -4, 
            "PapHt": -12, 
            "SpHt": -20
        }, 
        {
            "AbpHt": -12, 
            "CvpHt": 1, 
            "EcgIIHt": -3, 
            "EcgTag": 0, 
            "EcgV5Ht": -2, 
            "PapHt": -12, 
            "SpHt": -20
        }, 
        {
            "AbpHt": -12, 
            "CvpHt": 0, 
            "EcgIIHt": -1, 
            "EcgTag": 0, 
            "EcgV5Ht": -1, 
            "PapHt": -13, 
            "SpHt": -20
        }, 
        {
            "AbpHt": -12, 
            "CvpHt": 0, 
            "EcgIIHt": -1, 
            "EcgTag": 0, 
            "EcgV5Ht": -1, 
            "PapHt": -13, 
            "SpHt": -20
        }, 
        {
            "AbpHt": -13, 
            "CvpHt": 0, 
            "EcgIIHt": -1, 
            "EcgTag": 0, 
            "EcgV5Ht": -1, 
            "PapHt": -13, 
            "SpHt": -20
        }, 
        {
            "AbpHt": -13, 
            "CvpHt": 0, 
            "EcgIIHt": -1, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -12, 
            "SpHt": -19
        }, 
        {
            "AbpHt": -13, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -11, 
            "SpHt": -19
        }, 
        {
            "AbpHt": -12, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -10, 
            "SpHt": -18
        }, 
        {
            "AbpHt": -11, 
            "CvpHt": 1, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -9, 
            "SpHt": -17
        }, 
        {
            "AbpHt": -10, 
            "CvpHt": 1, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -9, 
            "SpHt": -16
        }, 
        {
            "AbpHt": -9, 
            "CvpHt": 2, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -8, 
            "SpHt": -15
        }, 
        {
            "AbpHt": -8, 
            "CvpHt": 2, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -8, 
            "SpHt": -14
        }, 
        {
            "AbpHt": -7, 
            "CvpHt": 2, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -8, 
            "SpHt": -13
        }, 
        {
            "AbpHt": -7, 
            "CvpHt": 2, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -8, 
            "SpHt": -12
        }, 
        {
            "AbpHt": -6, 
            "CvpHt": 2, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -12
        }, 
        {
            "AbpHt": -6, 
            "CvpHt": 1, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -11
        }, 
        {
            "AbpHt": -6, 
            "CvpHt": 1, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -11
        }, 
        {
            "AbpHt": -5, 
            "CvpHt": 1, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -10
        }, 
        {
            "AbpHt": -5, 
            "CvpHt": 1, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -10
        }, 
        {
            "AbpHt": -5, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -10
        }, 
        {
            "AbpHt": -5, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -9
        }, 
        {
            "AbpHt": -5, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -9
        }, 
        {
            "AbpHt": -5, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -9
        }, 
        {
            "AbpHt": -5, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -7, 
            "SpHt": -8
        }, 
        {
            "AbpHt": -5, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -6, 
            "SpHt": -8
        }, 
        {
            "AbpHt": -4, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -6, 
            "SpHt": -8
        }, 
        {
            "AbpHt": -4, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -6, 
            "SpHt": -7
        }, 
        {
            "AbpHt": -4, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -6, 
            "SpHt": -7
        }, 
        {
            "AbpHt": -4, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -6, 
            "SpHt": -7
        }, 
        {
            "AbpHt": -4, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -6, 
            "SpHt": -7
        }, 
        {
            "AbpHt": -4, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -6, 
            "SpHt": -7
        }, 
        {
            "AbpHt": -4, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -6, 
            "SpHt": -7
        }, 
        {
            "AbpHt": -4, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -6, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -6
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -5
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -5
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -5
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -5
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -5
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -5
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -5
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -5
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -5, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -3, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -4
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -4, 
            "SpHt": -3
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 0, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }, 
        {
            "AbpHt": -2, 
            "CvpHt": 0, 
            "EcgIIHt": 0, 
            "EcgTag": 1, 
            "EcgV5Ht": 0, 
            "PapHt": -3, 
            "SpHt": -2
        }
    ]
}